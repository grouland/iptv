<?php

class PassivoList extends TStandardList{

    public $datagrid;
    public $form;

    use Adianti\Base\AdiantiStandardListTrait;

    public function __construct(){

        parent:: __construct();
        //setando da onde vais sair os dados para a listagem
        parent::setDatabase('mymoney');
        parent::setActiveRecord('Passivos');
        parent::setDefaultOrder('id_passivo', 'asc');
        parent::addFilterField('usuario', '=',  TSession::getValue('userid')); //filterField, operator, formField

            //Criando Objeto de formulario
        $this->form = new BootstrapFormBuilder('form_passivo');
            //Definição do titulo do formulario
        $this->form->setFormTitle('Lista de Passivos');

            //objeto de imput
        $gasto = new TEntry('gasto');
        $gasto->setSize('100%');
            //criação do label
        $this->form->addFields([new TLabel('Gasto', null, '14px', null)],[$gasto]);
        $this->form->setData( TSession::getValue(__CLASS__.'_filter_data'));
        $btn_onsearch = $this->form->addAction('Buscar', new TAction([$this, 'onSearch']),'fa:search #ffffff');
        $btn_onshow = $this->form->addAction('Cadastrar', new TAction(['PassivoForm', 'onShow']),'fa:plus #69aa46');
        $btn_onsearch->addStyleClass('btn-primary');

        $this->datagrid = new BootstrapDatagridWrapper(new TQuickGrid);
        $this->datagrid->width = '100%';
        // $this->datagrid->datatable = 'true';

        $this->datagrid->addQuickColumn('ID',    'id_passivo', 'left');
        $this->datagrid->addQuickColumn('Nome',    'nome_passivo', 'left');
        $this->datagrid->addQuickColumn('Valor',    'valor_passivo', 'left');
        $this->datagrid->addQuickColumn('Tempo',    'tempo_passivo', 'left');

        $action1 = new TDataGridAction(array('PassivoForm', 'onEdit'));
        $action2 = new TDataGridAction(array($this, 'onDelete'));

        $this->datagrid->addQuickAction('Ver',   $action1, 'id_passivo', 'ico_find.png');
        $this->datagrid->addQuickAction('Deletar', $action2, 'id_passivo', 'ico_delete.png');

        //configurando cada ação/botão
        $action1->setUseButton(TRUE);
        $action1->setButtonClass('btn btn-default');
        $action1->setImage('fa:search blue');

        $action2->setUseButton(TRUE);
        $action2->setButtonClass('btn btn-default');
        $action2->setImage('fa:remove red');

        $this->datagrid->createModel();

        $this->pageNavigation = new TPageNavigation;
        $this->pageNavigation->enableCounters();
        $this->pageNavigation->setAction(new TAction(array($this, 'onReload')));
        $this->pageNavigation->setWidth($this->datagrid->getWidth());

        $panel = new TPanelGroup;
        $panel->add($this->datagrid);
        $panel->addFooter($this->pageNavigation);

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 90%';
        $container->add(new TXMLBreadCrumb('menu.xml', __CLASS__));
        $container->add($this->form);
        $container->add($panel);

        parent::add($container);


    }


    public function onSearch()
    {
        // get the search form data
        $data = $this->form->getData();

        // clear session filters
        TSession::setValue('filtro_passivo',   NULL);
        // TSession::setValue('SystemDocumentList_filter_category_id',   NULL);
        // TSession::setValue('SystemDocumentList_filter_filename',   NULL);

        if (isset($data->gasto)) {
            $filter = new TFilter('nome_passivo', 'like', "%{$data->gasto}%"); // create the filter
            TSession::setValue('filtro_passivo',   $filter); // stores the filter in the session

            // fill the form with data again
            $this->form->setData($data);
        }


        // keep the search data in the session
        // TSession::setValue('Passivos_filter_data', $data);

        $param=array();
        $param['offset']    =0;
        $param['first_page']=1;
        $this->onReload($param);
    }

    public function onReload($param = NULL)
    {
        try
        {
            // open a transaction with database 'communication'
            TTransaction::open($this->database);

            // creates a repository for SystemDocument
            $repository = new TRepository('Passivos');
            $limit = 10;
            // creates a criteria
            $criteria = new TCriteria;

            if(TSession::getValue('filtro_passivo')){

              $criteria->add(TSession::getValue('filtro_passivo'));

            }

            // default order
            if (empty($param['order']))
            {
                $param['order'] = 'id_passivo';
                $param['direction'] = 'asc';
            }
            $criteria->setProperties($param); // order, offset
            $criteria->setProperty('limit', $limit);

            if (TSession::getValue('login') !== 'admin')
            {
                $criteria->add(new TFilter('usuario', '=', TSession::getValue('userid')));
            }

            // load the objects according to criteria
            $objects = $repository->load($criteria);

            if (is_callable($this->transformCallback))
            {
                call_user_func($this->transformCallback, $objects, $param);
            }

            $this->datagrid->clear();
            if ($objects)
            {
                // iterate the collection of active records
                foreach ($objects as $object)
                {
                    // add the object inside the datagrid
                    $this->datagrid->addItem($object);
                }
            }

            // reset the criteria for record count
            $criteria->resetProperties();
            $count= $repository->count($criteria, FALSE);

            $this->pageNavigation->setCount($count); // count of records
            $this->pageNavigation->setProperties($param); // order, page
            $this->pageNavigation->setLimit($limit); // limit

            // close the transaction
            TTransaction::close();
            $this->loaded = true;
        }
        catch (Exception $e) // in case of exception
        {
            // shows the exception error message
            new TMessage('error', $e->getMessage());
            // undo all pending operations
            TTransaction::rollback();
        }
    }

    function clear()
    {
        $this->clearFilters();
        $this->onReload();
    }


}
