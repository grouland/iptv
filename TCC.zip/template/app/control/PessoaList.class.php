<?php
class PessoaList extends TStandardList{
    public $datagrid;
    public $form;
    protected $pageNavigation;
    //public $database = 'projeto1';
    //public $table = 'pessoa';
    use Adianti\Base\AdiantiStandardListTrait;

public function __construct(){
    parent::__construct();

    parent::setDatabase('projeto1');            // defines the database
    parent::setActiveRecord('pessoa');   // defines the active record
    parent::setDefaultOrder('id', 'asc');         // defines the default order

    $this->form = new BootstrapFormBuilder('form_Pessoa');

    // define the form title
    $this->form->setFormTitle('Listagem de Pessoas');
    $nome = new TEntry('nome');
    $nome->setSize('100%');

    $this->form->addFields([new TLabel('Nome da Pessoa:', null, '14px', null)],[$nome]);
    $this->form->setData( TSession::getValue(__CLASS__.'_filter_data') );

    $btn_onsearch = $this->form->addAction('Buscar', new TAction([$this, 'onSearch']),'fa:search #ffffff');
    $btn_onsearch->addStyleClass('btn-primary');
    $btn_onshow = $this->form->addAction('Cadastrar', new TAction(['PessoaForm', 'onShow']),'fa:plus #69aa46');

 


    //criando um datagrid
    $this->datagrid = new BootstrapDatagridWrapper(new TQuickGrid);
    $this->datagrid->width = '100%';

    //adicionar colunas
    $this->datagrid->addQuickColumn('ID',    'id', 'left');
    $this->datagrid->addQuickColumn('Nome',    'nome', 'left');
    $this->datagrid->addQuickColumn('E-mail',    'email', 'left');
    $this->datagrid->addQuickColumn('Salário',    'salario', 'left');    
    $this->datagrid->addQuickColumn('Dt Nasc.',    'data_nascimento', 'left');
    $this->datagrid->addQuickColumn('Criado Em',    'criado_em', 'left');

    //criar botão/ações da listagem
    //onView: para ver/editar os dados do cadastro
    $action1 = new TDataGridAction(array('PessoaForm', 'onEdit'));
    //onDelete: para deletar o cadastro
    $action2 = new TDataGridAction(array($this, 'onDelete'));
            
    // adicionando as ações ao datagrid
    $this->datagrid->addQuickAction('Ver',   $action1, 'id', 'ico_find.png');
    $this->datagrid->addQuickAction('Deletar', $action2, 'id', 'ico_delete.png');
        
    //configurando cada ação/botão
    $action1->setUseButton(TRUE);
    $action1->setButtonClass('btn btn-default');
    $action1->setImage('fa:search blue');
            
    $action2->setUseButton(TRUE);
    $action2->setButtonClass('btn btn-default');
    $action2->setImage('fa:remove red');

    //criar listagem
    $this->datagrid->createModel();

    
    // create the page navigation
    $this->pageNavigation = new TPageNavigation;
    $this->pageNavigation->enableCounters();
    $this->pageNavigation->setAction(new TAction(array($this, 'onReload')));
    $this->pageNavigation->setWidth($this->datagrid->getWidth());



    $panel = new TPanelGroup;
    $panel->add($this->datagrid);
    $panel->addFooter($this->pageNavigation);
      
    // vertical box container
    $container = new TVBox;
    $container->style = 'width: 90%';
    $container->add(new TXMLBreadCrumb('menu.xml', __CLASS__));
    $container->add($this->form);
    $container->add($panel);

    parent::add($container);

    }







    //FUNÇÕES
    
    
    // public function onSearch(){

    //    // get the search form data
    //    $data = $this->form->getData();
    //    $filters = [];
    
    
    //    TSession::setValue(__CLASS__.'_filter_data', NULL);
    //    TSession::setValue(__CLASS__.'_filters', NULL);
    
    
    
    
    //    if (isset($data->nome) AND ( (is_scalar($data->nome) AND $data->nome !== '') OR (is_array($data->nome) AND (!empty($data->nome)) )) )
    //    {
    
    
    //        $filters[] = new TFilter('nome', 'like', "%{$data->nome}%");// create the filter
    //    }
    
    
    //    $param = array();
    //    $param['offset']     = 0;
    //    $param['first_page'] = 1;
    
    
    //    // fill the form with data again
    //    $this->form->setData($data);
    
    
    //    // keep the search data in the session
    //    TSession::setValue(__CLASS__.'_filter_data', $data);
    //    TSession::setValue(__CLASS__.'_filters', $filters);
    
    
    //    $this->onReload($param);
    
    // }


    // public function onReload($param = NULL){
    //     try{
    //        TTransaction::open('projeto1');
    
    
    //        // creates a repository for Pessoa
    //        $repository = new TRepository('pessoa');
    //        $limit = 5;
    //        // creates a criteria
    //        $criteria = new TCriteria;
    
    
    //        if (empty($param['order']))
    //        {
    //            $param['order'] = 'nome';
    //        }
    
    
    //        if (empty($param['direction']))
    //        {
    //            $param['direction'] = 'asc';
    //        }
    
    
    //        $criteria->setProperties($param); // order, offset
    //        $criteria->setProperty('limit', $limit);
    
    
    //        if($filters = TSession::getValue(__CLASS__.'_filters'))
    //        {
    //            foreach ($filters as $filter)
    //            {
    //                $criteria->add($filter);
    //            }
    //        }
    
    
    //        // load the objects according to criteria
    //        $objects = $repository->load($criteria, FALSE);
    
    
    //        $this->datagrid->clear();
    //        if ($objects)
    //        {
    //            // iterate the collection of active records
    //            foreach ($objects as $object)
    //            {
    //                // add the object inside the datagrid
    
    
    //                $this->datagrid->addItem($object);
    
    
    //            }
    //        }
    
    
    //        // reset the criteria for record count
    //        $criteria->resetProperties();
    //        $count= $repository->count($criteria);
    
    
    
    
    //        // close the transaction
    //        TTransaction::close();
    //        $this->loaded = true;
    //     }
    //    catch (Exception $e){
    //        // shows the exception error message
    //        new TMessage('error', $e->getMessage());
    //        // undo all pending operations
    //        TTransaction::rollback();
    //     }   
    // }

    function clear()
    {
        $this->clearFilters();
        $this->onReload();
    }
}