<?php
/**
 * PessoaForm Form
 * @author  Rodrigo Warzak
 */
class AtivoForm extends TStandardForm
{
    protected $form; // form

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();
        parent::setDatabase('mymoney');
        parent::setActiveRecord('Ativos');


        // creates the form
        $this->form = new BootstrapFormBuilder('form_Ativo');
        $this->form->setFormTitle('Cadastro de Ativos');

        // $s = TSession::getValue('userid');
        // echo "$s";

        // $usuario   = new TEntry('usuario');
        // $usuario = TSession::getValue('userid');
        $nome_ativo = new TEntry('nome_ativo');
        $valor_ativo = new TNumeric('valor_ativo', 2, ',', '.', true);
        $tempo_ativo = new TCombo('tempo_ativo');

        $items = [ 30 => '30'];
        $tempo_ativo->addItems($items);

        $tempo_ativo->addValidation('de Dias a Receber', new TRequiredValidator());
        $nome_ativo->addValidation('Nome', new TRequiredValidator());

        // $id_ativo->setEditable(false);
        // $id_ativo->setSize(100);
        $nome_ativo->setSize('100%');


        // $this->form->addFields([new TLabel('Id:')],[$usuario = TSession::getValue('userid')]);
        // $this->form->addFields();
        $this->form->addFields([new TLabel('Nome do Ativo:')],[$nome_ativo]);
        $this->form->addFields([new TLabel('Valor do Ativo')],[$valor_ativo]);
        $this->form->addFields([new TLabel('Dias a Receber')],[$tempo_ativo]);

        // create the form actions
        $this->form->addAction('Salvar', new TAction([$this, 'onSave']), 'fa:floppy-o')->addStyleClass('btn-primary');

        $this->form->addAction('Limpar formulário', new TAction([$this, 'onClear']), 'fa:eraser #dd5a43');

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        //$container->add(new TXMLBreadCrumb('menu.xml', 'CidadeList'));
        $container->add($this->form);
        parent::add($container);
    }


    public function onShow($param = null){

    }

    /**
     * method onSave()
     * Executed whenever the user clicks at the save button
     */
    public function onSave($param = nul)
    {
        try
        {

            TTransaction::open('mymoney');
            $this->form->validate();

            if (isset($param['key']))
            {
              $object = new Ativos($param['key']);
            }else{
              $object = new Ativos();
            }
            $data = $this->form->getData(); // get form data as array()

            var_dump($data);

            $object->usuario =TSession::getValue('userid');
            $object->nome_ativo = $data->nome_ativo;
            $object->valor_ativo = $data->valor_ativo;
            $object->tempo_ativo = $data->tempo_ativo;
            $object->store();
            $data->id = $object->id;
            $this->form->setData($data);

            // $object->clearParts();

            TTransaction::close();

            new TMessage('info', AdiantiCoreTranslator::translate('Record saved'));

            return $object;
        }
        catch (Exception $e) // in case of exception
        {
            // get the form data
            $object = $this->form->getData($this->activeRecord);
            $this->form->setData($object);
            new TMessage('error', $e->getMessage());
            TTransaction::rollback();
        }
    }

    public function onEdit($param)
    {
        try
        {
            if (isset($param['key']))
            {
                // get the parameter $key
                $key=$param['key'];
                // open a transaction with database 'permission'
                TTransaction::open('mymoney');

                // instantiates object System_group
                $object = new Ativos($key);

                // fill the form with the active record data
                $this->form->setData($object);

                // close the transaction
                TTransaction::close();

                // TSession::setValue('ativos_list', $data);

            }
            else
            {
                $this->form->clear();
                TSession::setValue('ativos_list', null);
            }
        }
        catch (Exception $e) // in case of exception
        {
            // shows the exception error message
            new TMessage('error', $e->getMessage());

            // undo all pending operations
            TTransaction::rollback();
        }
    }

}
